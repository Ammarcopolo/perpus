<?php 
$link = mysqli_connect("localhost", "root", "", "dbperpus");
// mysql_connect('localhost','root','');
// mysql_select_db('dbperpus');
?>